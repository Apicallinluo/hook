#include "vmlinux.h"
#include <bpf/bpf_helpers.h>
struct enemy { __u16 x,y,z,hp; };
struct { __uint(type, BPF_MAP_TYPE_RINGBUF); __uint(max_entries, 1<<12); } rb SEC(".maps");
char _license[] SEC("license") = "GPL";
SEC("fentry/libUE4.so__ZN5UE412RenderFrameEv")
int BPF_PROG(get_enemy, void *uaddr){
    struct enemy e;
    void *p = (void*)uaddr + 0x130;
    bpf_probe_read_user(&e, sizeof(e), p);
    bpf_ringbuf_output(&rb, &e, sizeof(e), 0);
    return 0;
}
