#!/sbin/sh
while [ "$(getprop sys.boot_completed)" != "1" ]; do sleep 1; done
/system/bin/shadowoned &
