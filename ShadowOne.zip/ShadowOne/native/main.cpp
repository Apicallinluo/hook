#include "common.h"
extern "C" {
#include <bpf/libbpf.h>
#include "read.skel.h"
}
int main(){
    struct read_bpf *skel = read_bpf__open_and_load();
    read_bpf__attach(skel);
    while(true){
        struct enemy *e = bpf_ringbuf__consume(skel->maps.rb);
        if(!e) continue;
        printf("enemy x=%u y=%u
", e->x, e->y);
    }
    return 0;
}
